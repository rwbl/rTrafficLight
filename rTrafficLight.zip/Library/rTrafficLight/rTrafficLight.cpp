#include "B4RDefines.h"
namespace B4R
{
	void B4RTrafficLight::Initialize(Byte LedRedPin, Byte LedYellowPin, Byte LedGreenPin){
		//Assign the led pins to the private vars
		ledred 		= LedRedPin;
		ledyellow	= LedYellowPin;
		ledgreen	= LedGreenPin;

		//Set the pin modes to output
		pinMode(LedRedPin, OUTPUT);
		pinMode(LedYellowPin, OUTPUT);
		pinMode(LedGreenPin, OUTPUT);

		//Turn the traffic light off
		TurnOff();
	}

	void B4RTrafficLight::TurnOff(void){
		SetState(0, 0, 0);
	}	

	void B4RTrafficLight::TurnOn(void){
		SetState(1, 1, 1);
	}	

	void B4RTrafficLight::SetState(bool r, bool y, bool g){
		digitalWrite(ledred, r);
		digitalWrite(ledyellow, y);
		digitalWrite(ledgreen, g);
	}	

	ArrayByte* B4RTrafficLight::GetState(void) {
		UInt Length = 3;
		Array* arr = CreateStackMemoryObject(Array);
		arr->data = StackMemory::buffer + StackMemory::cp;
		StackMemory::cp += Length;
		arr->length = Length;
		((Byte*)arr->data)[0] = digitalRead(ledred);
		((Byte*)arr->data)[1] = digitalRead(ledyellow);
		((Byte*)arr->data)[2] = digitalRead(ledgreen);
		return arr;
	}

	void B4RTrafficLight::setRed(bool state){
		digitalWrite(ledred, state);
	}

	bool B4RTrafficLight::getRed(){
		return digitalRead(ledred) == 1;
	}

	void B4RTrafficLight::setYellow(bool state){
		digitalWrite(ledyellow, state);
	}

	bool B4RTrafficLight::getYellow(){
		return digitalRead(ledyellow) == 1;
	}

	void B4RTrafficLight::setGreen(bool state){
		digitalWrite(ledgreen, state);
	}

	bool B4RTrafficLight::getGreen(){
		return digitalRead(ledgreen) == 1;
	}

	void B4RTrafficLight::Simulate(void){
		//Start with RED
		SetState(1, 0, 0);
		delay(2000);		
		//Set YELLOW for 3 seconds
		SetState(0, 1, 0);
		delay(3000);		
		//Set GREEN
		SetState(0, 0, 1);
		delay(2000);		
		TurnOff();
	}

	B4RString* B4RTrafficLight::getVersion(void){
		PrintToMemory pm;
		B4RString* s = B4RString::PrintableToString(NULL);
		pm.print(version);
		StackMemory::buffer[StackMemory::cp++] = 0;
		return s;
	}

}